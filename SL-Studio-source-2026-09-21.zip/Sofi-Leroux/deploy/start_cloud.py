"""Production entry point: durable services, authenticated cabinet, HTTP/WS."""
from __future__ import annotations

import os
import json
import http.client
from pathlib import Path
import secrets
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def configure(environment):
    required = ('SCENA_TURSO_TURSO_DATABASE_URL', 'SCENA_TURSO_TURSO_AUTH_TOKEN',
                'SCENA_PUBLIC_BLOB_READ_WRITE_TOKEN', 'SCENA_PRIVATE_BLOB_READ_WRITE_TOKEN',
                'SCENA_ADMIN_PASSWORD', 'SCENA_PUBLIC_BASE_URL')
    missing = [name for name in required if not environment.get(name, '').strip()]
    if missing:
        raise RuntimeError('Missing SCENA configuration: ' + ', '.join(missing))
    if len(environment['SCENA_ADMIN_PASSWORD'].strip()) < 8:
        raise RuntimeError('The administrator password must contain at least eight characters.')
    from urllib.parse import urlsplit
    origin = urlsplit(environment['SCENA_PUBLIC_BASE_URL'].strip())
    if origin.scheme != 'https' or not origin.hostname or origin.username or origin.password or origin.path not in ('', '/') or origin.query or origin.fragment:
        raise RuntimeError('Configure the new installation HTTPS origin in SCENA_PUBLIC_BASE_URL.')
    environment['SCENA_PUBLIC_BASE_URL'] = environment['SCENA_PUBLIC_BASE_URL'].strip().rstrip('/')
    environment['SCENA_ADMIN_PASSWORD'] = environment['SCENA_ADMIN_PASSWORD'].strip()
    environment['SCENA_CLOUD'] = '1'
    environment['SCENA_DB_PATH'] = '/tmp/scena-cloud/scena_master.db'
    environment['SCENA_APP_DIR'] = str(ROOT)
    environment['PYTHONPATH'] = str(ROOT)
    environment.pop('SCENA_PREVIEW_ONLY', None)
    # A launcher must always initialize; only its child may inherit completion.
    environment.pop('SCENA_INITIALIZED_DB', None)
    return environment


def wait_for_backend(backend, *, port=8501, timeout=30):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline and backend.poll() is None:
        connection = http.client.HTTPConnection('127.0.0.1', port, timeout=0.5)
        try:
            connection.request('GET', '/_stcore/health')
            response = connection.getresponse()
            if response.status == 200:
                response.read()
                return
        except (OSError, http.client.HTTPException):
            pass
        finally:
            connection.close()
        time.sleep(0.05)
    raise RuntimeError('SCENA application did not become ready before the startup deadline.')


def main():
    started = time.monotonic()
    os.environ.update(configure(dict(os.environ)))
    os.environ.pop('SCENA_PREVIEW_ONLY', None)
    os.environ.pop('SCENA_INITIALIZED_DB', None)
    Path(os.environ['SCENA_DB_PATH']).parent.mkdir(parents=True, exist_ok=True)
    from scena_cloud_runtime import initialize_application
    from scena_database import connect
    from scena_core import get_settings, save_settings
    print('SCENA: initializing durable database', flush=True)
    initialize_application(os.environ['SCENA_DB_PATH'])
    os.environ['SCENA_INITIALIZED_DB'] = os.environ['SCENA_DB_PATH']
    database_ready = time.monotonic() - started
    connection = connect(os.environ['SCENA_DB_PATH'])
    try:
        connection.execute("INSERT OR IGNORE INTO app_meta(key,value) VALUES ('cloud_session_key',?)", (secrets.token_hex(32),))
        connection.commit()
        os.environ['SCENA_SESSION_SIGNING_KEY'] = connection.execute("SELECT value FROM app_meta WHERE key='cloud_session_key'").fetchone()[0]
        from scena_cloud_auth import password_tag
        # A cold start of an old deployment must never reactivate its password.
        deployment = os.environ.get('VERCEL_DEPLOYMENT_ID') or os.environ.get('VERCEL_URL')
        marker = 'cloud_auth_deployment:' + deployment if deployment else None
        connection.execute('BEGIN IMMEDIATE')
        if not marker or not connection.execute('SELECT 1 FROM app_meta WHERE key=?', (marker,)).fetchone():
            connection.execute("INSERT INTO app_meta(key,value) VALUES ('cloud_auth_version',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (password_tag(),))
            if marker:
                connection.execute('INSERT INTO app_meta(key,value) VALUES (?,?)', (marker, '1'))
        connection.commit()
    finally:
        connection.close()
    settings = get_settings(os.environ['SCENA_DB_PATH'])
    domain = os.environ['SCENA_PUBLIC_BASE_URL'].removeprefix('https://')
    if not settings.get('public_base_url') or 'localhost' in settings['public_base_url']:
        save_settings(os.environ['SCENA_DB_PATH'], {'public_base_url': 'https://' + domain})
    report = {'status': 'ok', 'boot_id': secrets.token_hex(8), 'commit': os.environ.get('VERCEL_GIT_COMMIT_SHA', 'local')}
    if os.environ.get('VERCEL') == '1':
        from scena_cloud_checks import verify_services
        try:
            report.update(verify_services())
        except Exception as error:
            print('SCENA: service check error type ' + type(error).__name__, flush=True)
            raise RuntimeError('SCENA durable service acceptance failed; inspect the configured database and Blob connections.') from None
    print('SCENA: durable services ready', flush=True)
    services_ready = time.monotonic() - started
    os.chdir(ROOT)
    backend = subprocess.Popen([
        sys.executable, '-m', 'streamlit', 'run', 'scena-master-standalone.py',
        '--server.address', '127.0.0.1', '--server.port', '8501',
        '--server.headless', 'true', '--server.enableStaticServing', 'false',
    ])
    gateway = None
    def stop(*_):
        backend.terminate()
        if gateway is not None:
            gateway.terminate()
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    try:
        wait_for_backend(backend)
        report['startup_seconds'] = {
            'database_ready': round(database_ready, 3),
            'services_ready': round(services_ready, 3),
            'application_ready': round(time.monotonic() - started, 3),
        }
        os.environ['SCENA_HEALTH_REPORT'] = json.dumps(report)
        print('SCENA: startup ' + json.dumps(report['startup_seconds']), flush=True)
        gateway = subprocess.Popen([sys.executable, 'deploy/serve_cloud.py'])
        while backend.poll() is None and gateway.poll() is None:
            time.sleep(0.25)
    finally:
        stop()
        backend.wait(timeout=10)
        if gateway is not None:
            gateway.wait(timeout=10)
    raise SystemExit(backend.returncode or gateway.returncode or 0)


if __name__ == '__main__':
    main()
