"""Run an explicitly temporary SCENA preview in a writable container directory.

Production hosting must use durable database/media adapters instead of this
launcher. Credentials are supplied privately at deployment time, never in Git.
"""
from __future__ import annotations

import os
from pathlib import Path
import shutil
import sys
import tempfile


def prepare_runtime(source: Path, runtime: Path) -> Path:
    """Copy application code and bundled images, never an owner's database."""
    runtime.mkdir(parents=True, exist_ok=False)
    for file in source.glob("*.py"):
        shutil.copyfile(file, runtime / file.name)
    shutil.copytree(source / "media", runtime / "media")
    (runtime / ".streamlit").mkdir()
    shutil.copyfile(source / ".streamlit/config.toml", runtime / ".streamlit/config.toml")
    return runtime


def preview_password(environment: dict[str, str]) -> str | None:
    password = environment.get("SCENA_ADMIN_PASSWORD", "").strip()
    if not password:
        return None
    # A temporary eight-character password is allowed in this isolated preview.
    # main() still rejects production; never embed a default password.
    if len(password) < 8:
        raise RuntimeError("The private preview password must contain at least 8 characters.")
    return password


def main() -> None:
    environment = dict(os.environ)
    if environment.get("VERCEL_ENV") == "production":
        raise RuntimeError("This launcher is for preview deployments only.")
    source = Path(__file__).resolve().parents[1]
    password = preview_password(environment)
    temporary_parent = Path(tempfile.mkdtemp(prefix="scena-preview-"))
    runtime = prepare_runtime(source, temporary_parent / "app")
    if password:
        environment["SCENA_ADMIN_PASSWORD"] = password
    else:
        environment.pop("SCENA_ADMIN_PASSWORD", None)
    environment["SCENA_PREVIEW_ONLY"] = "1"
    environment["SCENA_DB_PATH"] = str(runtime / "scena_master.db")
    environment["PYTHONPATH"] = str(runtime)
    port = int(environment.get("PORT", "80"))
    if not 1 <= port <= 65535:
        raise ValueError("Invalid listening port.")
    os.chdir(runtime)
    os.execvpe(sys.executable, [
        sys.executable, "-m", "streamlit", "run", "scena-master-standalone.py",
        "--server.address", "0.0.0.0", "--server.port", str(port),
        "--server.headless", "true",
    ], environment)


if __name__ == "__main__":
    main()
